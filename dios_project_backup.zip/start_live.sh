#!/bin/bash
set -e
cd /workspaces/Dios

echo "=========================================================================="
echo "🚀 STARTING DIOS UNIFIED SYSTEM (PORT 8000 BACKEND + PORT 5173 FRONTEND)..."
echo "=========================================================================="

# 1. Kill old processes
pkill -f uvicorn || true
pkill -f vite || true
sleep 1

# 2. Install Playwright browser if needed
playwright install chromium >/dev/null 2>&1 || true

# 3. Start Python Backend (Port 8000) in Background
export PYTHONUNBUFFERED=1
nohup python3 -u -m uvicorn server:app --host 0.0.0.0 --port 8000 > /workspaces/Dios/server.log 2>&1 &
sleep 2

# 4. Start Vite Frontend (Port 5173) in Background
nohup npx vite --host 0.0.0.0 --port 5173 > /workspaces/Dios/vite.log 2>&1 &
sleep 2

# 5. Make ports public
gh codespace ports visibility 8000:public -c $CODESPACE_NAME 2>/dev/null || true
gh codespace ports visibility 5173:public -c $CODESPACE_NAME 2>/dev/null || true

echo "=========================================================================="
echo "🎉 SYSTEM IS 100% LIVE & ACTIVE!"
echo "👉 Web App Link:     https://${CODESPACE_NAME}-5173.app.github.dev"
echo "👉 Live Terminal:    https://${CODESPACE_NAME}-8000.app.github.dev"
echo "=========================================================================="
