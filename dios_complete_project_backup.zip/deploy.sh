#!/bin/bash
set -e

export CLOUDFLARE_API_TOKEN="cfk_gD8RWflFpUaIaQ8TsSO9RZPuDEPR5FCLrDGyOPBKc79cec4d"
export CLOUDFLARE_API_KEY="cfk_gD8RWflFpUaIaQ8TsSO9RZPuDEPR5FCLrDGyOPBKc79cec4d"
export CLOUDFLARE_EMAIL="litx18kyt@gmail.com"

echo "🚀 1. Building Vite project..."
npm run build

echo "☁️ 2. Deploying to Cloudflare Pages Production..."
npx wrangler pages deploy dist --project-name=dios-hub --branch=main --commit-dirty=true

echo ""
echo "========================================================"
echo "✅ DEPLOYMENT FINISHED SUCCESSFULLY!"
echo "🌐 LIVE URL: https://dios-hub.pages.dev"
echo "========================================================"
