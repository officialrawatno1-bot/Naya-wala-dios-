import { onRequest as __api_download_primary_excel_ts_onRequest } from "/workspaces/Naya-wala-dios-/functions/api/download-primary-excel.ts"
import { onRequest as __api_extraction_status_ts_onRequest } from "/workspaces/Naya-wala-dios-/functions/api/extraction-status.ts"
import { onRequest as __api_fetch_cbo_excel_ts_onRequest } from "/workspaces/Naya-wala-dios-/functions/api/fetch-cbo-excel.ts"
import { onRequest as __api_fetch_dcr_ts_onRequest } from "/workspaces/Naya-wala-dios-/functions/api/fetch-dcr.ts"
import { onRequest as __api_fetch_dcr_calls_ts_onRequest } from "/workspaces/Naya-wala-dios-/functions/api/fetch-dcr-calls.ts"
import { onRequest as __api_fetch_dcr_excel_ts_onRequest } from "/workspaces/Naya-wala-dios-/functions/api/fetch-dcr-excel.ts"
import { onRequest as __api_fetch_primary_ts_onRequest } from "/workspaces/Naya-wala-dios-/functions/api/fetch-primary.ts"
import { onRequest as __api_fetch_sales_performance_ts_onRequest } from "/workspaces/Naya-wala-dios-/functions/api/fetch-sales-performance.ts"
import { onRequest as __api_load_local_csv_ts_onRequest } from "/workspaces/Naya-wala-dios-/functions/api/load-local-csv.ts"
import { onRequest as __api_retry_missed_dates_ts_onRequest } from "/workspaces/Naya-wala-dios-/functions/api/retry-missed-dates.ts"
import { onRequest as __api_start_dcr_extraction_ts_onRequest } from "/workspaces/Naya-wala-dios-/functions/api/start-dcr-extraction.ts"

export const routes = [
    {
      routePath: "/api/download-primary-excel",
      mountPath: "/api",
      method: "",
      middlewares: [],
      modules: [__api_download_primary_excel_ts_onRequest],
    },
  {
      routePath: "/api/extraction-status",
      mountPath: "/api",
      method: "",
      middlewares: [],
      modules: [__api_extraction_status_ts_onRequest],
    },
  {
      routePath: "/api/fetch-cbo-excel",
      mountPath: "/api",
      method: "",
      middlewares: [],
      modules: [__api_fetch_cbo_excel_ts_onRequest],
    },
  {
      routePath: "/api/fetch-dcr",
      mountPath: "/api",
      method: "",
      middlewares: [],
      modules: [__api_fetch_dcr_ts_onRequest],
    },
  {
      routePath: "/api/fetch-dcr-calls",
      mountPath: "/api",
      method: "",
      middlewares: [],
      modules: [__api_fetch_dcr_calls_ts_onRequest],
    },
  {
      routePath: "/api/fetch-dcr-excel",
      mountPath: "/api",
      method: "",
      middlewares: [],
      modules: [__api_fetch_dcr_excel_ts_onRequest],
    },
  {
      routePath: "/api/fetch-primary",
      mountPath: "/api",
      method: "",
      middlewares: [],
      modules: [__api_fetch_primary_ts_onRequest],
    },
  {
      routePath: "/api/fetch-sales-performance",
      mountPath: "/api",
      method: "",
      middlewares: [],
      modules: [__api_fetch_sales_performance_ts_onRequest],
    },
  {
      routePath: "/api/load-local-csv",
      mountPath: "/api",
      method: "",
      middlewares: [],
      modules: [__api_load_local_csv_ts_onRequest],
    },
  {
      routePath: "/api/retry-missed-dates",
      mountPath: "/api",
      method: "",
      middlewares: [],
      modules: [__api_retry_missed_dates_ts_onRequest],
    },
  {
      routePath: "/api/start-dcr-extraction",
      mountPath: "/api",
      method: "",
      middlewares: [],
      modules: [__api_start_dcr_extraction_ts_onRequest],
    },
  ]